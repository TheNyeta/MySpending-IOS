//
//  Helper.swift
//  MySpendings
//
//  Created by prk on 27/11/21.
//  Copyright © 2021 prk. All rights reserved.
//

import Foundation

class Helper {
    static func isOnlyNumber(str: String) -> Bool{
        for i in str {
            if i < "0" || i > "9" {
                return false
            }
        }
        return true
    }
    
    static func toNumeric(str: String) -> String {
        var count = 0
        var result = ""
        
        for i in str.reversed() {
            count += 1
            result = "\(i)\(result)"
            if count % 3 == 0 && count != str.count  {
                result = ",\(result)"
            }
        }
        
        return result
        
    }
    
}
