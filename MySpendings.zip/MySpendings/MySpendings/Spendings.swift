//
//  Spendings.swift
//  MySpendings
//
//  Created by prk on 27/11/21.
//  Copyright © 2021 prk. All rights reserved.
//

import Foundation

struct Spendings{
    var name:String
    var price:Int
    var category:String
}
