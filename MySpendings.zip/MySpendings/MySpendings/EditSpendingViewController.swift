//
//  EditSpendingViewController.swift
//  MySpendings
//
//  Created by prk on 27/11/21.
//  Copyright © 2021 prk. All rights reserved.
//

import UIKit

protocol editSpending{
    func editSpending(name:String, price:Int, category:String)
}

class EditSpendingViewController: UIViewController {

    var delegate:editSpending?
    
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var priceField: UITextField!
    @IBOutlet weak var categoryChoice: UISegmentedControl!
    
    var name:String?
    var price:Int?
    var category:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        nameField.text = name
        priceField.text = String(price!)
        
        if category == "food" {
            categoryChoice.selectedSegmentIndex = 0
        }else if category == "fun" {
            categoryChoice.selectedSegmentIndex = 1
        }else if category == "transport" {
            categoryChoice.selectedSegmentIndex = 2
        }else if category == "other" {
            categoryChoice.selectedSegmentIndex = 3
        }
        
        // Do any additional setup after loading the view.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func alert(msg:String, handler:((UIAlertAction)-> Void)?) {
        let alert = UIAlertController(title: "Alert", message: msg, preferredStyle: .actionSheet)
        
        let ok = UIAlertAction(title: "Ok", style: .default, handler: handler)
        
        alert.addAction(ok)
        present(alert, animated: true, completion: nil)
    }

    
    @IBAction func indexChanged(_ sender: Any) {
        switch categoryChoice.selectedSegmentIndex{
        case 0:
            category = "food"
        case 1:
            category =  "fun"
        case 2:
            category = "transport"
        case 3:
            category = "other"
        default:
            break
        }
    }
    
    @IBAction func saveButton(_ sender: Any) {
        let newName = nameField.text!
        let newPrice = priceField.text!
        
        if newName == "" {
            alert(msg: "Please input the name of spending", handler: nil)
        }else if newName.count < 5 {
            alert(msg: "Name must be more than 5 characters", handler: nil)
        }else if newPrice == "" {
            alert(msg: "Please input the price of spending", handler: nil)
        }else if !Helper.isOnlyNumber(str: newPrice){
            alert(msg: "Price must be only number", handler: nil)
        }else if category == "" {
            alert(msg: "Please choose a category", handler: nil)
        }else{
            delegate?.editSpending(name: newName, price: Int(newPrice)!, category: category!)
            
            performSegue(withIdentifier: "backToHome", sender: self)
        }
    }
    
    @IBAction func backButton(_ sender: Any) {
        performSegue(withIdentifier: "backToHome", sender: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
