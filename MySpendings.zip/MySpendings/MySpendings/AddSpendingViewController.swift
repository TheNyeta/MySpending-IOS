//
//  AddSpendingViewController.swift
//  MySpendings
//
//  Created by prk on 27/11/21.
//  Copyright © 2021 prk. All rights reserved.
//

import UIKit

protocol addSpending{
    func addNewSpending(name:String, price:Int, category:String)
}

class AddSpendingViewController: UIViewController {

    var delegate:addSpending?
    
    var category:String = ""
    
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var priceField: UITextField!
    @IBOutlet weak var categoryChoice: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    func alert(msg:String, handler:((UIAlertAction)-> Void)?) {
        let alert = UIAlertController(title: "Alert", message: msg, preferredStyle: .actionSheet)
        
        let ok = UIAlertAction(title: "Ok", style: .default, handler: handler)
        
        alert.addAction(ok)
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func backButton(_ sender: Any) {
        performSegue(withIdentifier: "backToHome", sender: self)
    }
    
    @IBAction func indexChanged(_ sender: Any) {
        switch categoryChoice.selectedSegmentIndex{
        case 0:
            category = "food"
        case 1:
            category =  "fun"
        case 2:
            category = "transport"
        case 3:
            category = "other"
        default:
            break
        }
    }
    
    @IBAction func addSpendingButton(_ sender: Any) {
        let name = nameField.text!
        let price = priceField.text!
        
        if name == "" {
            alert(msg: "Please input the name of spending", handler: nil)
        }else if name.count < 5 {
            alert(msg: "Name must be more than 5 characters", handler: nil)
        }else if price == "" {
            alert(msg: "Please input the price of spending", handler: nil)
        }else if !Helper.isOnlyNumber(str: price){
            alert(msg: "Price must be only number", handler: nil)
        }else if category == "" {
            alert(msg: "Please choose a category", handler: nil)
        }else{
            delegate?.addNewSpending(name: name, price: Int(price)!, category: category)
            
            performSegue(withIdentifier: "backToHome", sender: self)
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
