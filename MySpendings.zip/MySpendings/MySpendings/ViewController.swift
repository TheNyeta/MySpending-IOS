//
//  ViewController.swift
//  MySpendings
//
//  Created by prk on 27/11/21.
//  Copyright © 2021 prk. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var spendingList = [Spendings]()
    var index = 0
    var showTotal = false
    
    @IBOutlet weak var spendingTableView: UITableView!
    
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var totalPriceLabel: UILabel!
    
    func initSpendings(){
        spendingList.append(Spendings(name: "Fried Chicken", price: 24000, category: "food"))
        spendingList.append(Spendings(name: "Movies", price: 60000, category: "fun"))
        spendingList.append(Spendings(name: "Comute", price: 20000, category: "transport"))
        spendingList.append(Spendings(name: "Mobile Data 10GB", price: 100900, category: "other"))
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        initSpendings()
        spendingTableView.dataSource = self
        spendingTableView.delegate = self
        
        updateTotalPrice()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let app = UIApplication.shared
        NotificationCenter.default.addObserver(self, selector: #selector(applicationWillEnterForeground(_:)), name: UIApplication.willEnterForegroundNotification, object: app)
    }
    
    @objc func applicationWillEnterForeground(_ notification: NSNotification) {
        updateTotalPrice()
    }
    
    func updateTotalPrice() {
        
        let defaults = UserDefaults.standard
        showTotal = defaults.bool(forKey: "showTotal")
        
        if showTotal {
            
            var total = 0
            
            for i in spendingList {
                total += i.price
            }
            
            totalLabel.text = "Total:"
            totalPriceLabel.text = "Rp \(Helper.toNumeric(str: String(total)))"
        }else{
            totalLabel.text = ""
            totalPriceLabel.text = ""
        }
        
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func goToAddSpending(_ sender: Any) {
        performSegue(withIdentifier: "addSpending", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "addSpending" {
            let nav = segue.destination as! UINavigationController
            let dest = nav.viewControllers.first as! AddSpendingViewController
            dest.delegate = self
        }else if segue.identifier == "editSpending" {
            let nav = segue.destination as! UINavigationController
            let dest = nav.viewControllers.first as! EditSpendingViewController
            dest.name = spendingList[index].name
            dest.price = spendingList[index].price
            dest.category = spendingList[index].category
            dest.delegate = self
        }
    }
    
    @IBAction func unwindToHome(_ unwindSegue: UIStoryboardSegue) {
//        let sourceViewController = unwindSegue.source
        // Use data from the view controller which initiated the unwind segue
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            spendingList.remove(at: indexPath.row)
            updateTotalPrice()
            spendingTableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        index = indexPath.row
        performSegue(withIdentifier: "editSpending", sender: self)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return spendingList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let spendingCell = tableView.dequeueReusableCell(withIdentifier: "spendingCell", for: indexPath) as! SpendingTableViewCell
        
        spendingCell.spendingName.text = spendingList[indexPath.row].name
        spendingCell.spendingPrice.text = "Rp \(Helper.toNumeric(str: String(spendingList[indexPath.row].price)))"
        spendingCell.spendingImg.image = UIImage(named: spendingList[indexPath.row].category)
        
        return spendingCell
    }

}

extension ViewController:addSpending, editSpending {
    func addNewSpending(name: String, price: Int, category: String) {
        
        spendingList.append(Spendings(name: name, price: price, category: category))
        updateTotalPrice()
        spendingTableView.reloadData()
    }
    
    func editSpending(name: String, price: Int, category: String) {
        
        spendingList[index].name = name
        spendingList[index].price = price
        spendingList[index].category = category
        updateTotalPrice()
        spendingTableView.reloadData()
    }
    
}
